package com.example.android.dutchpay;


public class FriendListActivity {
    
}
